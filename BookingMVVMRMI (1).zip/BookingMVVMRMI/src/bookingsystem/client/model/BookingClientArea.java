package bookingsystem.client.model;

import bookingsystem.shared.transferobjects.Customer;
import bookingsystem.shared.transferobjects.LogEntry;
import bookingsystem.shared.transferobjects.Vehicle;
import bookingsystem.shared.util.Subject;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public interface BookingClientArea extends Subject {

    String toServer(String text,String userId);

    List<LogEntry> getLogs();
    void setServerUserId(String str);

    void addCustomerData(String personId,String gender,String name,String surname);

    void removeCustomer(String personId)  ;
    Customer findCustomer(String personId) ;
    List<Customer> getCustomers();

    void addVehicleData(String Id,String name,String category, LocalDate year) ;
    void removeVehicle(String Id) ;
    Vehicle findVehicle(String Id) ;
    List<Vehicle> getVehicles() ;
}


