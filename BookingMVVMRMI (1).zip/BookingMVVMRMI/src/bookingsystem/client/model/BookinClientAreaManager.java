package bookingsystem.client.model;

import bookingsystem.client.network.Client;
import bookingsystem.shared.transferobjects.Customer;
import bookingsystem.shared.transferobjects.CustomerList;
import bookingsystem.shared.transferobjects.LogEntry;
import bookingsystem.shared.transferobjects.Vehicle;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public class BookinClientAreaManager implements BookingClientArea, Serializable
{
    private PropertyChangeSupport support = new PropertyChangeSupport(this);
    private Client client;

    public BookinClientAreaManager(Client client) {
        this.client = client;
        client.startClient();
        client.addListener("NewLogEntry", this::onNewLogEntry);
    }

    private void onNewLogEntry(PropertyChangeEvent evt) {
        support.firePropertyChange(evt);
    }

    @Override
    public String toServer(String text,String userId) {
        return client.netClientToServer(text,userId);
    }


    @Override
    public List<LogEntry> getLogs() {
        return client.getLog();
    }

    @Override public void setServerUserId(String str)
    {
        client.setUserId(str);
    }


    @Override
    public void addCustomerData(String personId,String gender,String name,String surname) {
        client.addCustomerData(personId, gender, name, surname);
    }

    @Override public void removeCustomer(String personId)
    {
        client.removeCustomer(personId);
    }

    @Override public Customer findCustomer(String personId)
    {
        return  client.findCustomer(personId);
    }

    @Override public List<Customer> getCustomers()
    {
        return client.getCustomers();
    }

    @Override public void addVehicleData(String Id, String name,
        String category, LocalDate year)
    {
        client.addVehicleData( Id,  name,category,  year);
    }

    @Override public void removeVehicle(String Id)
    {
        client.removeVehicle(Id);
    }

    @Override public Vehicle findVehicle(String Id)
    {
        return client.findVehicle(Id);
    }

    @Override public List<Vehicle> getVehicles()
    {
        return client.getVehicles();
    }

    @Override
    public void addListener(String eventName, PropertyChangeListener listener) {
        support.addPropertyChangeListener(eventName, listener);
    }

    @Override
    public void removeListener(String eventName, PropertyChangeListener listener) {
        support.removePropertyChangeListener(eventName, listener);
    }
}


