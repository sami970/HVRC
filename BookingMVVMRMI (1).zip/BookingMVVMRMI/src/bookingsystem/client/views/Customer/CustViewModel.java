package bookingsystem.client.views.Customer;

import bookingsystem.client.model.BookingClientArea;
import bookingsystem.shared.transferobjects.Customer;

import java.sql.ResultSet;

public class CustViewModel
{
    private BookingClientArea bookingClientArea;

    public CustViewModel(BookingClientArea bookingClientArea) {
        this.bookingClientArea = bookingClientArea;

    }


    public void addCustomerData(String personId,String gender,String name,String surname)
    {
        bookingClientArea.addCustomerData( personId, gender, name, surname);
    }

    public void removeCustomer(String personId)
    {
        bookingClientArea.removeCustomer(personId);
    }

     public Customer findCustomer(String personId)
    {
        return  bookingClientArea.findCustomer(personId);
    }
}
