package bookingsystem.client.views.Customer;

import bookingsystem.client.core.ViewHandler;
import bookingsystem.client.core.ViewModelFactory;
import bookingsystem.client.views.ViewController;
import bookingsystem.shared.transferobjects.Customer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class PersonTabController implements ViewController
{
    @FXML
    private ResourceBundle resources;

    @FXML
    private TextField errorField;

    @FXML
    private Button addButt;
    @FXML Button mainMenue;

    @FXML
    private TextField genderField;

    @FXML
    private GridPane gridpane;

    @FXML
    private TextField nameField;


    @FXML
    private TextField personField;

    @FXML
    private Button removeButt;

    @FXML
    private TextField surnameField;


    private final ObservableList<String> personData = FXCollections.observableArrayList();
    private ViewHandler vh;
    private CustViewModel viewModel;

    public void init(ViewHandler vh, ViewModelFactory vmf) {
        this.vh = vh;
        this.viewModel = vmf.getCustViewModel();
        this.initialize();
    }

    @FXML
    void handleMainMenueAction(ActionEvent event) {
        vh.openLoginSystem();
    }

    @FXML
    void handleClearAction(ActionEvent event)
    {
        refresh();
    }
    
    @FXML
    void handleAddApplyPersonAction(ActionEvent event) {

        this.viewModel.addCustomerData(personField.getText(),genderField.getText(),nameField.getText(),surnameField.getText());
        refresh();
    }

    @FXML
    void handleRemovePersonAction(ActionEvent event) throws IOException {
        this.viewModel.removeCustomer(personField.getText());
        refresh();
    }

    @FXML
    void handleFindAction(ActionEvent event)
    {
        String person = personField.getText();
        errorField.setText("");

        Customer cust =this.viewModel.findCustomer(person);

        if (cust !=null)
        {
            nameField.setText(cust.getName());
            surnameField.setText(cust.getSurName());
            personField.setText(cust.getPersonId());
            genderField.setText(cust.getGender());
        } else
        {
            errorField.setText("Not found...");
        }

    }

    void initialize() {
        assert addButt != null : "fx:id=\"addButt\" was not injected: check your FXML file 'PersonTab.fxml'.";

        assert genderField != null : "fx:id=\"genderCBox\" was not injected: check your FXML file 'PersonTab.fxml'.";
        assert gridpane != null : "fx:id=\"gridpane\" was not injected: check your FXML file 'PersonTab.fxml'.";
        assert nameField != null : "fx:id=\"nameField\" was not injected: check your FXML file 'PersonTab.fxml'.";

        assert personField != null : "fx:id=\"personCBox\" was not injected: check your FXML file 'PersonTab.fxml'.";
        assert removeButt != null : "fx:id=\"removeButt\" was not injected: check your FXML file 'PersonTab.fxml'.";
        assert surnameField != null : "fx:id=\"surnameField\" was not injected: check your FXML file 'PersonTab.fxml'.";
    }


    private void refresh(){
        personData.removeAll(personData);
        personData.add("");
        errorField.setText("");
        nameField.setText("");
        surnameField.setText("");
        personField.setText("");
        genderField.setText("");
    }


}

