package bookingsystem.client.views.login;

import bookingsystem.client.core.ViewHandler;
import bookingsystem.client.core.ViewModelFactory;
import bookingsystem.client.views.ViewController;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javafx.scene.control.TextField;

public class LoginViewController implements ViewController {
    @FXML
    private Label errorLabel;

    @FXML
    private TextField passwordField;

    @FXML
    private TextField userId;
    @FXML
    private Button CustmerListButton;

    @FXML
    private Button LoginListButton;
    @FXML  Button CustmerButton;

    @FXML
    Button VehicleButton;
    @FXML
    Button VehicleListButton;
    @FXML
    Button BookinButton;
    @FXML
    Button BookinListButton;

    private LoginViewModel viewModel;
    private ViewHandler vh;

    public void init(ViewHandler vh, ViewModelFactory vmf) {
        this.vh = vh;
        this.viewModel = vmf.getLoginViewModel();
        errorLabel.textProperty().bind(viewModel.errorProperty());
        passwordField.textProperty().bindBidirectional(viewModel.requestProperty());

        userId.textProperty().bindBidirectional(viewModel.replyUserIdProperty());
        // Disable controls

        userId.setText("");
       LoginListButton.setDisable(true);
       userId.setDisable(false);
       passwordField.setDisable(false);
       CustmerButton.setDisable(true);
       LoginListButton.setDisable(true);
       CustmerListButton.setDisable(true);
       VehicleButton.setDisable(true);
       VehicleListButton.setDisable(true);
       BookinButton.setDisable(true);
       BookinListButton.setDisable(true);

    }


    @FXML
    private void onLoginButton() {

            viewModel.submitToserver();
            passwordField.setText("");
            passwordField.setDisable(true);
            userId.setText("");
            userId.setDisable(true);
            LoginListButton.setDisable(false);
            CustmerButton.setDisable(false);
            LoginListButton.setDisable(false);
            CustmerListButton.setDisable(false);
            VehicleButton.setDisable(false);
            VehicleListButton.setDisable(false);
    }


    @FXML
    private void onCustomerListButton()
    {
        vh.openCustomerList();
    }
    @FXML
    private void onCustomerButton()
    {

        vh.openCustomer();
    }

  @FXML
  private void onVehicleListButton()
  {
    vh.openVehicleList();
  }
  @FXML
  private void onVehicleButton()
  {

    vh.openVehicle();
  }
    public void onLoginListButton() {
        vh.openLog();
    }


}

