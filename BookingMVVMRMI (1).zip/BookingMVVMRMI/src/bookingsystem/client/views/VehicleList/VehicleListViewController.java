package bookingsystem.client.views.VehicleList;

import bookingsystem.client.core.ViewHandler;
import bookingsystem.client.core.ViewModelFactory;
import bookingsystem.client.views.CustomerList.CustomerListViewModel;
import bookingsystem.client.views.ViewController;
import bookingsystem.shared.transferobjects.Customer;
import bookingsystem.shared.transferobjects.Vehicle;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class VehicleListViewController implements ViewController {


    @FXML
    private TableView<Vehicle> tableView;
    public TableColumn<String, Vehicle> nameColumn;
    public TableColumn<String, Vehicle> IdColumn;

    private VehicleListViewModel vm;
    private ViewHandler vh;

    @Override
    public void init(ViewHandler vh, ViewModelFactory vmf) {
        this.vh = vh;
        vm = vmf.getVehicleListViewModel();
        vm.loadVehicleList();
        tableView.setItems(vm.getVehicles());

        nameColumn.setCellValueFactory(new PropertyValueFactory<>("Id"));
        IdColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
    }
    @FXML
    public void onRefreshButton()
    {
        vm.loadVehicleList();
        tableView.setItems(vm.getVehicles());
    }
    @FXML
    public void onBackButton() {
        vh.openLoginSystem();
    }
}
