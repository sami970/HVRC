package bookingsystem.client.views.VehicleList;

import bookingsystem.client.model.BookingClientArea;

import bookingsystem.shared.transferobjects.Vehicle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.ArrayList;

public class VehicleListViewModel
{

    private ObservableList<Vehicle> Logs;

    private BookingClientArea bookingClientArea;

    public VehicleListViewModel(BookingClientArea clientArea) {
        this.bookingClientArea = clientArea;

    }


    void loadVehicleList() {
        ArrayList<Vehicle> vehicleList = (ArrayList<Vehicle>) bookingClientArea.getVehicles();
        Logs = FXCollections.observableArrayList(vehicleList);
    }

    ObservableList<Vehicle> getVehicles() {
        return Logs;
    }
}
