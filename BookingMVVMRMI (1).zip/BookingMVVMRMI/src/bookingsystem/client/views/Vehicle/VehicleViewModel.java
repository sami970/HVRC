package bookingsystem.client.views.Vehicle;

import bookingsystem.client.model.BookingClientArea;

import bookingsystem.shared.transferobjects.Vehicle;

import java.rmi.RemoteException;
import java.time.LocalDate;

public class VehicleViewModel
{
    private BookingClientArea bookingClientArea;

    public VehicleViewModel(BookingClientArea bookingClientArea) {
        this.bookingClientArea = bookingClientArea;

    }

    public void addVehicleData(String Id,String name,String category, LocalDate year)
    {
        bookingClientArea.addVehicleData(  Id, name, category,  year);
    }

    public void removeVehicle(String id)
    {
        bookingClientArea.removeVehicle(id);
    }

     public Vehicle findVehicle(String id) throws RemoteException
     {
        return  bookingClientArea.findVehicle(id);
    }
}
