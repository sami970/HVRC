package bookingsystem.client.views.Vehicle;

import bookingsystem.client.core.ViewHandler;
import bookingsystem.client.core.ViewModelFactory;

import bookingsystem.client.views.ViewController;

import bookingsystem.shared.transferobjects.Vehicle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.rmi.RemoteException;
import java.time.LocalDate;
import java.util.Date;
import java.util.ResourceBundle;

public class VehicleTabController implements ViewController
{

    @FXML
    private TextField errorField;

    @FXML
    private Button addButt;
    @FXML Button mainMenue;

    @FXML
    private TextField categoryField;

    @FXML
    private GridPane gridpane;

    @FXML
    private TextField nameField;


    @FXML
    private TextField vehicleField;

    @FXML
    private Button removeButt;

    @FXML
    private DatePicker dateField;


    private final ObservableList<String> vehicleData = FXCollections.observableArrayList();
    private ViewHandler vh;
    private VehicleViewModel viewModel;

    public void init(ViewHandler vh, ViewModelFactory vmf) {
        this.vh = vh;
        this.viewModel = vmf.getVehicleViewModel();
        this.initialize();
    }

    @FXML
    void handleMainMenueAction(ActionEvent event) {
        vh.openLoginSystem();
    }

    @FXML
    void handleClearAction(ActionEvent event)
    {
        refresh();
    }
    
    @FXML
    void handleAddApplyVehicleAction(ActionEvent event) {
        LocalDate value = dateField.getValue();

        this.viewModel.addVehicleData(vehicleField.getText(),categoryField.getText(),nameField.getText(),value);
        refresh();
    }

    @FXML
    void handleRemoveVehicleAction(ActionEvent event) throws IOException {
        this.viewModel.removeVehicle(vehicleField.getText());
        refresh();
    }

    @FXML
    void handleFindAction(ActionEvent event) throws RemoteException
    {
        String id = vehicleField.getText();
        errorField.setText("");

        Vehicle vehicle =this.viewModel.findVehicle(id);

        if (vehicle !=null)
        {
            nameField.setText(vehicle.getName());
            dateField.setValue(vehicle.getyear());
            vehicleField.setText(vehicle.getId());
            categoryField.setText(vehicle.getCategory());
        } else
        {
            errorField.setText("Not found...");
        }

    }

    void initialize() {
        assert addButt != null : "fx:id=\"addButt\" was not injected: check your FXML file 'Vehicle.fxml'.";

        assert categoryField != null : "fx:id=\"categoryField\" was not injected: check your FXML file 'Vehicle.fxml'.";

        assert nameField != null : "fx:id=\"nameField\" was not injected: check your FXML file 'Vehicle.fxml'.";

        assert vehicleField != null : "fx:id=\"vehicleField\" was not injected: check your FXML file 'Vehicle.fxml'.";
        assert removeButt != null : "fx:id=\"removeButt\" was not injected: check your FXML file 'Vehicle.fxml'.";
        assert dateField != null : "fx:id=\"dateField\" was not injected: check your FXML file 'Vehicle.fxml'.";
    }


    private void refresh(){
        vehicleData.removeAll(vehicleData);
        vehicleData.add("");
        errorField.setText("");
        nameField.setText("");
        dateField.setValue(null);
        vehicleField.setText("");
        categoryField.setText("");
    }


}

