package bookingsystem.client.views.CustomerList;

import bookingsystem.client.core.ViewHandler;
import bookingsystem.client.core.ViewModelFactory;
import bookingsystem.client.views.ViewController;
import bookingsystem.shared.transferobjects.Customer;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class CustomerListViewController implements ViewController {


    @FXML
    private TableView<Customer> tableView;
    public TableColumn<String, Customer> nameColumn;
    public TableColumn<String,Customer> persnIdColumn;

    private CustomerListViewModel vm;
    private ViewHandler vh;

    @Override
    public void init(ViewHandler vh, ViewModelFactory vmf) {
        this.vh = vh;
        vm = vmf.getCustListViewModel();
        vm.loadCustomerList();
        tableView.setItems(vm.getCustomers());

        nameColumn.setCellValueFactory(new PropertyValueFactory<>("PersonId"));
        persnIdColumn.setCellValueFactory(new PropertyValueFactory<>("Name"));
    }
    @FXML
    public void onRefreshButton()
    {
        vm.loadCustomerList();
        tableView.setItems(vm.getCustomers());
    }
    @FXML
    public void onBackButton() {
        vh.openLoginSystem();
    }
}
