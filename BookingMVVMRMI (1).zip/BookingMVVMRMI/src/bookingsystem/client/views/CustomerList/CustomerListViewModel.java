package bookingsystem.client.views.CustomerList;

import bookingsystem.client.model.BookingClientArea;
import bookingsystem.shared.transferobjects.Customer;

import bookingsystem.shared.transferobjects.CustomerList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.beans.PropertyChangeEvent;
import java.util.ArrayList;


public class CustomerListViewModel
{

    private ObservableList<Customer> Logs;

    private BookingClientArea bookingClientArea;

    public CustomerListViewModel(BookingClientArea clientArea) {
        this.bookingClientArea = clientArea;

    }


    void loadCustomerList() {
        ArrayList<Customer> custList = (ArrayList<Customer>) bookingClientArea.getCustomers();
        Logs = FXCollections.observableArrayList(custList);
    }

    ObservableList<Customer> getCustomers() {
        return Logs;
    }
}
