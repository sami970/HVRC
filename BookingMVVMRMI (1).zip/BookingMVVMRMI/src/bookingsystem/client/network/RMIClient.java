package bookingsystem.client.network;

import bookingsystem.shared.networking.ClientCallback;
import bookingsystem.shared.networking.RMIServer;
import bookingsystem.shared.transferobjects.Customer;
import bookingsystem.shared.transferobjects.LogEntry;
import bookingsystem.shared.transferobjects.Vehicle;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public class RMIClient implements  Client, ClientCallback
{
  private RMIServer server;
  private PropertyChangeSupport support;

  public RMIClient()
  {
     support = new PropertyChangeSupport(this);
  }

  @Override public void startClient()
  {
    try
    {
      UnicastRemoteObject.exportObject(this,0);
      Registry registry= LocateRegistry.getRegistry("localhost",1099);
      server =(RMIServer)registry.lookup("BookingServer");
      server.registerClient(this);
    }
    catch (RemoteException | NotBoundException e)
    {
      e.printStackTrace();
    }

  }

  @Override public String netClientToServer(String str,String userId)
  {
    try {
      return server.loginToServer(str,userId);
    } catch (RemoteException e) {
      throw new RuntimeException("Could not contact server");
    }
  }

  @Override
  public void addCustomerData(String personId,String gender,String name,String surname)
  {
    try
    {
      server.addCustomerData( personId, gender, name, surname);
    }
    catch (RemoteException e)
    {
      e.printStackTrace();
    }
  }

  @Override public void removeCustomer(String personId)
  {
    try
    {
      server.removeCustomer(personId);
    }
    catch (RemoteException e)
    {
      e.printStackTrace();
    }
  }

  @Override public Customer findCustomer(String personId)
  {
    Customer ret =null;
    try
    {
      ret = server.findCustomer(personId);
    }
    catch (RemoteException e)
    {
      e.printStackTrace();
    }
    return ret;
  }



  @Override public List<LogEntry> getLog()
  {
    try
    {
      return server.getLog();
    } catch (RemoteException e) {
      throw new RuntimeException("Could not contact server");
    }
  }

  @Override public void setUserId(String str)
  {
    try
    {
      server.setUserId(str);
    }
    catch (RemoteException e)
    {
      e.printStackTrace();
    }
  }

  @Override public List<Customer> getCustomers()
  {
    List<Customer> ret =null;
    try
    {
      ret = server.getCustomers();
    }
    catch (RemoteException e)
    {
      e.printStackTrace();
    }
    return ret;
  }

  @Override public void addVehicleData(String Id, String name, String category,
      LocalDate year)
  {
    try
    {
      server.addVehicleData( Id,  name,  category, year);
    }
    catch (RemoteException e)
    {
      e.printStackTrace();
    }
  }

  @Override public void removeVehicle(String Id)
  {
    try
    {
      server.removeVehicle(Id);
    }
    catch (RemoteException e)
    {
      e.printStackTrace();
    }
  }

  @Override public Vehicle findVehicle(String Id)
  {
    Vehicle ret=null;
    try
    {
      ret= server.findVehicle(Id);
    }
    catch (RemoteException e)
    {
      e.printStackTrace();
    }
    return ret;
  }

  @Override public List<Vehicle> getVehicles()
  {
    List<Vehicle> ret = null;
    try
    {
      ret = server.getVehicles();
    }
    catch (RemoteException e)
    {
      e.printStackTrace();
    }
    return ret;
  }

  @Override public void update(LogEntry log)
  {
     support.firePropertyChange("NewLogEntry",null,log);
  }

  @Override public void addListener(String eventName,
      PropertyChangeListener listener)
  {
     support.addPropertyChangeListener(eventName, listener);
  }

  @Override public void removeListener(String eventName,
      PropertyChangeListener listener)
  {
     support.removePropertyChangeListener(eventName, listener);
  }
}
