package bookingsystem.client.network;

import bookingsystem.shared.transferobjects.Customer;
import bookingsystem.shared.transferobjects.LogEntry;
import bookingsystem.shared.transferobjects.Vehicle;
import bookingsystem.shared.util.Subject;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public interface Client extends Subject {

    String netClientToServer(String str,String userId);

    List<LogEntry> getLog();

    void addCustomerData(String personId,String gender,String name,String surname);
    void removeCustomer(String personId)  ;
    Customer findCustomer(String personId) ;

    void startClient();
    void setUserId(String str);
    List<Customer> getCustomers();

    void addVehicleData(String Id,String name,String category, LocalDate year);
    void removeVehicle(String Id) ;
    Vehicle findVehicle(String Id) ;
    List<Vehicle> getVehicles() ;
}
