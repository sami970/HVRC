package bookingsystem.client.core;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import bookingsystem.client.views.ViewController;

import java.io.IOException;

public class ViewHandler {

    //Screens
    private Scene loginScene;
    private Stage stage;
    private Scene logScene;
    private Scene customerScene;
    private Scene customerListScene;
    private Scene vehicleScene;
    private Scene vehicleListScene;

    private ViewModelFactory vmf;

    public ViewHandler(ViewModelFactory vmf) {
        this.vmf = vmf;
    }

    public void start() {
        stage = new Stage();
        openLoginSystem();
    }

    public void openLoginSystem() {
        if (loginScene == null) {
            try {
                Parent root = loadFXML("../views/login/LoginView.fxml");
                loginScene = new Scene(root);
                stage.setTitle("Booking System");


            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        stage.setScene(loginScene);
        stage.show();

    }

    public void openLog() {

        if (logScene == null) {
            try {
                Parent root = loadFXML("../views/log/Log.fxml");

                logScene = new Scene(root);
                //stage.setTitle("Log..");

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        stage.setScene(logScene);
        stage.show();
    }
    public void openVehicleList() {

        if (vehicleListScene == null) {
            try {
                Parent root = loadFXML("../views/VehicleList/VehicleList.fxml");

                vehicleListScene = new Scene(root);

                //stage.setTitle("Log..");

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        stage.setScene(vehicleListScene);
        stage.show();
    }

    public void openCustomer(){
        if (customerScene == null) {
            try {
                Parent root = loadFXML("../views/Customer/PersonTab.fxml");

                customerScene = new Scene(root);
                //stage.setTitle("Log..");


            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        stage.setScene(customerScene);
        stage.show();
    }

    public void openCustomerList () {

        if (customerListScene == null) {
            try {
                Parent root = loadFXML("../views/CustomerList/CustomerList.fxml");

                customerListScene = new Scene(root);

                //stage.setTitle("Log..");

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        stage.setScene(customerListScene);
        stage.show();
    }

    public void openVehicle(){
        if (vehicleScene == null) {
            try {
                Parent root = loadFXML("../views/Vehicle/Vehicle.fxml");

                vehicleScene = new Scene(root);
                //stage.setTitle("Log..");


            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        stage.setScene(vehicleScene);
        stage.show();
    }


    private Parent loadFXML(String path) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(path));
        Parent root = loader.load();

        ViewController ctrl = loader.getController();
        ctrl.init(this, vmf);
        return root;
    }
}
