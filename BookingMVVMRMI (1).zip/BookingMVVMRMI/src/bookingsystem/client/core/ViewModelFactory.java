package bookingsystem.client.core;

import bookingsystem.client.views.Customer.CustViewModel;
import bookingsystem.client.views.CustomerList.CustomerListViewModel;
import bookingsystem.client.views.Vehicle.VehicleViewModel;
import bookingsystem.client.views.VehicleList.VehicleListViewModel;
import bookingsystem.client.views.log.LogViewModel;
import bookingsystem.client.views.login.LoginViewModel;

public class ViewModelFactory {

    private final ModelFactory mf;
    private LoginViewModel loginViewModel;
    private LogViewModel logViewModel;
    private CustViewModel custViewModel;
    private CustomerListViewModel customerListViewModel;
    private VehicleViewModel vehicleViewModel;
    private VehicleListViewModel vehicleListViewModel;

    public ViewModelFactory(ModelFactory mf) {
        this.mf = mf;
    }

    public LoginViewModel getLoginViewModel() {
        if (loginViewModel == null)
            loginViewModel = new LoginViewModel(mf.getBookingClientArea());
        return loginViewModel;
    }

    public LogViewModel getLogViewModel() {
        return (logViewModel = logViewModel == null ?
                new LogViewModel(mf.getBookingClientArea()) :
                logViewModel);
    }
    public CustViewModel getCustViewModel() {
        return (custViewModel = custViewModel == null ?
            new CustViewModel(mf.getBookingClientArea()) :
            custViewModel);
    }

    public CustomerListViewModel getCustListViewModel() {
        return (customerListViewModel = customerListViewModel == null ?
            new CustomerListViewModel(mf.getBookingClientArea()) :
            customerListViewModel);
    }

    public VehicleViewModel getVehicleViewModel() {
        return (vehicleViewModel = vehicleViewModel == null ?
            new VehicleViewModel(mf.getBookingClientArea()) :
            vehicleViewModel);
    }

    public VehicleListViewModel getVehicleListViewModel() {
        return (vehicleListViewModel = vehicleListViewModel == null ?
            new VehicleListViewModel(mf.getBookingClientArea()) :
            vehicleListViewModel);
    }
}
