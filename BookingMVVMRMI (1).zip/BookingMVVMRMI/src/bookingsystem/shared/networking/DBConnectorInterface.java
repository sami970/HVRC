package bookingsystem.shared.networking;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public interface DBConnectorInterface
{

  public Connection getConnection();
  public Connection connect(String url, String user, String password, String database);

  public  ResultSet getResultSet(String str);
  public void executeStatement(String str);
  public int getNextId(String tableName);

}
