package bookingsystem.shared.networking;

import bookingsystem.shared.transferobjects.Customer;
import bookingsystem.shared.transferobjects.LogEntry;
import bookingsystem.shared.transferobjects.Vehicle;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public interface RMIServer extends Remote
{
  String loginToServer(String str,String userId) throws RemoteException;
  List<LogEntry> getLog()throws RemoteException;
  void setUserId(String userId)throws RemoteException;
  String getUserId() throws RemoteException;
  void registerClient(ClientCallback client) throws RemoteException;


  void addCustomerData(String personId,String gender,String name,String surname) throws RemoteException;
  void removeCustomer(String personId) throws RemoteException;
  Customer findCustomer(String personId) throws RemoteException;
  List<Customer> getCustomers() throws RemoteException;

  void addVehicleData(String Id,String name,String category, LocalDate year) throws RemoteException;
  void removeVehicle(String Id) throws RemoteException;
  Vehicle findVehicle(String Id) throws RemoteException;
  List<Vehicle> getVehicles() throws RemoteException;

}
