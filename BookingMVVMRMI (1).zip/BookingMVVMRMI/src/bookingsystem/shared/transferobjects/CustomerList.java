package bookingsystem.shared.transferobjects;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CustomerList implements Serializable
{
  private List<Customer> customersEntries;

  public CustomerList() {
    customersEntries = new ArrayList<>();
  }

  public List<Customer> getCustomers()
  {
    return this.customersEntries;
  }

  public void addNewCustomer(Customer cust ) {

    this.customersEntries.add(cust);
  }

  public Customer findCustomer(String personId) {
    Customer ret = null;

    for(int i =0; i < customersEntries.size(); i++){
      Customer cust = (Customer)this.customersEntries.get(i);
      if (cust.getPersonId().equals(personId))
      {
         ret = cust;
      }
    }
    return ret;
  }

  public void removeCustomer(String personId) {
    for(int i =0; i < customersEntries.size(); i++){
      Customer cust = (Customer)this.customersEntries.get(i);
      if (cust.getPersonId().equals(personId))
      {
        this.customersEntries.remove(i);
      }
    }
  }
}
