package bookingsystem.shared.transferobjects;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class VehicleList implements Serializable
{
  private List<Vehicle> vehicleEntries;

  public VehicleList() {
    vehicleEntries = new ArrayList<>();
  }

  public List<Vehicle> getVehicles()
  {
    return this.vehicleEntries;
  }

  public void addNewVehicle(Vehicle vehicle ) {

    this.vehicleEntries.add(vehicle);
  }

  public Vehicle findVehicle(String id) {
    Vehicle ret = null;

    for(int i =0; i < vehicleEntries.size(); i++){
      Vehicle vehic = (Vehicle)this.vehicleEntries.get(i);
      if (vehic.getId().equals(id))
      {
        ret = vehic;
      }
    }
    return ret;
  }

  public void removeVehicle(String id) {
    for(int i =0; i < vehicleEntries.size(); i++){
      Vehicle vehic = (Vehicle)this.vehicleEntries.get(i);
      if (vehic.getId().equals(id))
      {
        this.vehicleEntries.remove(i);
      }
    }
  }
}
