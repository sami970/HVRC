package bookingsystem.shared.transferobjects;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

public class Vehicle implements Serializable
{
  private String Id;
  private String name;
  private String category;
  private LocalDate year;

  public Vehicle(String Id,String name,String category,LocalDate year) {
    this.Id = Id;
    this.category = category;
    this.name = name;
    this.year = year;
  }

  public String getId()
  {
    return this.Id;
  }

  public String getName()
  {
    return this.name;
  }

  public String getCategory() {
    return this.category;
  }

  public LocalDate getyear()
  {
    return this.year;
  }
}
