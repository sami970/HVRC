package bookingsystem.shared.transferobjects;

import java.io.Serializable;

public class Customer implements Serializable
{
  private  String surname;
  private String name;
  private String gender;
  private String  personId;

  public Customer(String personId,String gender,String name,String surname) {
    this.personId = personId;
    this.gender = gender;
    this.name = name;
    this.surname = surname;
  }

  public String getPersonId()
  {
    return this.personId;
  }

  public String getName()
  {
    return this.name;
  }

  public String getGender() {
    return this.gender;
  }

  public String getSurName()
  {
    return this.surname;
  }
}


