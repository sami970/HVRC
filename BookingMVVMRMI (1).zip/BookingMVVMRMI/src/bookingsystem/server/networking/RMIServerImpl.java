package bookingsystem.server.networking;

import bookingsystem.server.model.ServerBookingManager;
import bookingsystem.shared.networking.ClientCallback;
import bookingsystem.shared.networking.RMIServer;
import bookingsystem.shared.transferobjects.Customer;
import bookingsystem.shared.transferobjects.LogEntry;
import bookingsystem.shared.transferobjects.Vehicle;

import java.beans.PropertyChangeListener;
import java.io.Serializable;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public class RMIServerImpl implements RMIServer
{
  private final ServerBookingManager serverBookingManager;
  public RMIServerImpl(ServerBookingManager serverBookingManager) throws RemoteException
  {
    UnicastRemoteObject.exportObject(this,0);
    this.serverBookingManager = serverBookingManager;
  }

  public void startServer() throws RemoteException, AlreadyBoundException
  {
    Registry registry= LocateRegistry.createRegistry(1099);
    registry.bind("BookingServer",this);
  }

  @Override public String loginToServer(String str, String userId)
      throws RemoteException
  {
    return serverBookingManager.serverData(str,userId);
  }

  @Override
  public void addCustomerData(String personId,String gender,String name,String surname) throws RemoteException
  {
     serverBookingManager.addCustomerData(personId, gender, name, surname);
  }

  @Override public void removeCustomer(String personId) throws RemoteException
  {
    serverBookingManager.removeCustomer(personId);
  }

  @Override public Customer findCustomer(String personId) throws RemoteException
  {
    return serverBookingManager.findCustomer(personId);
  }

  @Override public List<Customer> getCustomers() throws RemoteException
  {
    return serverBookingManager.getCustomers();
  }

  @Override public List<LogEntry> getLog()
  {
    return serverBookingManager.getLog();
  }

  @Override public void setUserId(String userId)
  {
    serverBookingManager.setUserId(userId);
  }

  @Override public String getUserId()
  {
    return serverBookingManager.getUserId();
  }

  @Override public void registerClient(ClientCallback client)

  {
    PropertyChangeListener listener = null;
    PropertyChangeListener finalListener=listener;

    listener=evt ->
    {
      try
      {
        client.update((LogEntry)evt.getNewValue());
      }
      catch (RemoteException e)
      {
         serverBookingManager.removeListener("NewLogEntry",finalListener);
      }
    };
     serverBookingManager.addListener("NewLogEntry",listener);
  }

  @Override public void addVehicleData(String Id,String name,String category,
      LocalDate year) throws RemoteException
  {
    serverBookingManager.addVehicleData(Id,name,category,year);
  }

  @Override public void removeVehicle(String Id) throws RemoteException
  {
    serverBookingManager.removeVehicle(Id);
  }

  @Override public Vehicle findVehicle(String Id) throws RemoteException
  {
    return serverBookingManager.findVehicle(Id);
  }

  @Override public List<Vehicle> getVehicles() throws RemoteException
  {
    return serverBookingManager.getVehicles();
  }

}
