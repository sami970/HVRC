package bookingsystem.server.networking;

import bookingsystem.shared.networking.DBConnectorInterface;

import java.io.Serializable;
import java.sql.*;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBConnector implements DBConnectorInterface, Serializable
{
  private final static DBConnector instance = new DBConnector();

  private static Connection conn = null;

  @Override public Connection getConnection()
  {
    return conn;
  }

  @Override public Connection connect(String url, String user, String password,   String database)
  {
    Connection ret = null;
    if (conn !=null)
    {
      ret = this.conn;
    }
    try {
      // db parameters
      Class.forName("org.sqlite.JDBC");

      // create a connection to the database
      conn = DriverManager.getConnection(url);
      ret = conn;
      System.out.println("Connection to SQLite has been established.");

    } catch (SQLException | ClassNotFoundException e) {
      System.out.println(e.getMessage());
    }
    return ret;
  }

  public void executeStatement(String str){
    try {

      Statement st = conn.createStatement();
      st.executeUpdate(str);
    } catch (SQLException ex) {
      System.out.println(ex.getMessage());
    }
  }

  public  ResultSet getResultSet(String str){
    try {

      Statement stmt = conn.createStatement();
      ResultSet rs = stmt.executeQuery(str);
      return rs;
    } catch (SQLException ex) {
      System.out.println(ex.getMessage());
      return null;
    }
  }

  public int getNextId(String tableName){
    try {

      Statement stmt = conn.createStatement();
      ResultSet rs = stmt.executeQuery("SELECT (r.Id + 1) AS firstId\n" +
          "FROM " + tableName + " r\n" +
          "LEFT JOIN  " + tableName + " r1 ON r1.Id = r.Id + 1\n" +
          "WHERE r1.Id IS NULL\n" +
          "ORDER BY r.Id\n" +
          "LIMIT 0,1");
      if (rs.next()){ return rs.getInt("firstId");}
      else { return 0; }
    } catch (SQLException ex) {
      System.out.println(ex.getMessage());
      return -1;
    }
  }

}
