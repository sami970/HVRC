package bookingsystem.server.model;

import bookingsystem.server.networking.DBConnector;
import bookingsystem.shared.networking.DBConnectorInterface;
import bookingsystem.shared.transferobjects.*;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ServerBookingManagerImpl implements ServerBookingManager
{

    private PropertyChangeSupport support;
    private List<LogEntry> logEntries;
   // private List<Customer> customersEntries;
    private String userId;
    private Connection conn;

    private CustomerList customersEntries;
    private VehicleList vehiclesEntries;


    public ServerBookingManagerImpl() {
        support = new PropertyChangeSupport(this);
        logEntries = new ArrayList<>();
        customersEntries = new CustomerList();
        vehiclesEntries = new VehicleList();
    }

    @Override
    public String serverData(String str,String userId) {
        String result = str;
        LogEntry logEntry = new LogEntry(result,userId);
        logEntries.add(logEntry);
        support.firePropertyChange("NewLogEntry", null, logEntry);
        return result;
    }

    @Override
    public void addCustomerData(String personId,String gender,String name,String surname)  throws RemoteException
    {
        Customer costum = new Customer(personId, gender, name, surname);
        customersEntries.addNewCustomer(costum);
    }

    @Override public void removeCustomer(String personId) throws RemoteException
    {
        customersEntries.removeCustomer(personId);
    }

    @Override public Customer findCustomer(String personId)
        throws RemoteException
    {
        return customersEntries.findCustomer(personId);
    }

  @Override public List<Customer> getCustomers()
  {
    return customersEntries.getCustomers();
  }

  @Override public void addVehicleData(String Id, String name, String category,
      LocalDate year) throws RemoteException
  {
    Vehicle vh = new Vehicle(Id,  name,  category, year);
    vehiclesEntries.addNewVehicle(vh);
  }

  @Override public void removeVehicle(String Id)
  {
    vehiclesEntries.removeVehicle(Id);
  }

  @Override public Vehicle findVehicle(String Id) throws RemoteException
  {
    return vehiclesEntries.findVehicle(Id);
  }

  @Override public List<Vehicle> getVehicles() throws RemoteException
  {
    return vehiclesEntries.getVehicles();
  }

    @Override
    public List<LogEntry> getLog() {
        return new ArrayList<>(logEntries);
    }

    @Override public void setUserId(String userId)
    {
        this.userId =userId;
    }

    @Override public String getUserId()
    {
        return this.userId;
    }



    @Override
    public void addListener(String eventName, PropertyChangeListener listener) {
        support.addPropertyChangeListener(eventName, listener);
    }

    @Override
    public void removeListener(String eventName, PropertyChangeListener listener) {
        support.removePropertyChangeListener(eventName, listener);
    }


}
