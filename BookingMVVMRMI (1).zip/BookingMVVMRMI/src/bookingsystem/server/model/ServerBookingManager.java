package bookingsystem.server.model;


import bookingsystem.shared.transferobjects.Customer;
import bookingsystem.shared.transferobjects.LogEntry;
import bookingsystem.shared.transferobjects.Vehicle;
import bookingsystem.shared.util.Subject;

import java.rmi.RemoteException;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

public interface ServerBookingManager extends Subject {

    String serverData(String str,String userId);
    List<LogEntry> getLog();
    void setUserId(String userId);
    String getUserId();



    void addCustomerData(String personId,String gender,String name,String surname)  throws RemoteException;

    void removeCustomer(String personId)  throws RemoteException;
    Customer findCustomer(String personId)  throws RemoteException;
    List<Customer> getCustomers();

    void addVehicleData(String Id,String name,String category, LocalDate year) throws RemoteException;
    void removeVehicle(String Id) throws RemoteException;
    Vehicle findVehicle(String Id) throws RemoteException;
    List<Vehicle> getVehicles() throws RemoteException;
}
