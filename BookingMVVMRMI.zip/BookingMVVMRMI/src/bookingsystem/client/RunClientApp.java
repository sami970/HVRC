package bookingsystem.client;

import javafx.application.Application;

public class RunClientApp
{

    public static void main(String[] args) {
        Application.launch(ClientApp.class);
    }

}
