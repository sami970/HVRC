package bookingsystem.client.views.mainMenue;

public class MainMenuViewModel
{
}
